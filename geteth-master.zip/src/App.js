import React, { Component } from "react";
import NoMetamask from "./components/NoMetamask";
import Header from "./components/Header";
import Content from "./components/Content";
import Footer from "./components/Footer";
// import FAQ from "./components/FAQ";
import { connect } from "react-redux";
import { fetchCourses } from "./store/courses";
import "./app.sass";
import { fetchValues } from "./store/values";

class App extends Component {
    state = {
        status: "LOADING"
    };

    initData() {
        setInterval(this.props.fetchEverything, 20 * 1000);
        this.props.fetchEverything();
    }

    componentWillMount() {
        if (!window.web3) {
            this.setState({
                status: "NOT_INSTALLED"
            });
            return;
        }
        window.web3.eth.getAccounts((err, accs) => {
            if (accs[0]) {
                window.web3.version.getNetwork((err, network) => {
                    if (network === "4") {
                        this.setState({
                            status: "OK"
                        });
                        this.initData();
                        return;
                    } else {
                        this.setState({
                            status: "WRONG_NETWORK"
                        });
                        return;
                    }
                });
            } else {
                this.setState({
                    status: "NOT_LOGGED_IN"
                });
                return;
            }
        });
    }

    render() {
        return (
            <div>
                <NoMetamask status={this.state.status}/>
                <div className={`${this.state.status !== "OK" ? "blur" : ""} content`}>
                    <Header isOnExchange={true}/>
                    <Content/>
                    <Footer/>
                </div>
            </div>
        );
    }
}

export default connect(
    false,
    dispatch => ({
        fetchEverything: () => {
            dispatch(fetchCourses());
            dispatch(fetchValues());
        }
    })
)(App);
