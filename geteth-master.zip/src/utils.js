export function shortAddr(address, num) {
    if (address) {
        return `${address.substring(0, num)}...${address.substr(-num)}`;
    } else {
        return 0;
    }
}
