import lang from './language';
import contract from './contract';
import courses from './courses';
import values from './values';
import percents from './percents';
import {createStore, combineReducers, applyMiddleware} from 'redux';
import thunk from 'redux-thunk';

const store = createStore(
  combineReducers({
    lang,
    contract,
    courses,
    values,
    percents
  }),
  applyMiddleware(thunk)
);

export default store;
