const initState = {
  getEth: 0,
  ethDollar: 0
};

export const fetchCourses = () => (dispatch, getState) => {
  getState().contract.price((err, res) => {
    dispatch({
      type: "CHANGE_GET/ETH_COURSE",
      course: window.web3.fromWei(res.toNumber(), 'ether'),
    });
  });
  fetch("https://getethtestserver1.herokuapp.com/dollarCourse")
    .then(res => res.json())
    .then(({ course }) => {
      dispatch({
        type: "CHAGE_ETH/DOLLAR_COURSE",
        course
      });
    });
};

export default (state = initState, action) => {
  switch (action.type) {
    case "CHANGE_GET/ETH_COURSE":
      return { ...state, getEth: action.course };
    case "CHAGE_ETH/DOLLAR_COURSE":
      return { ...state, ethDollar: action.course };
    default:
      return state;
  }
};
