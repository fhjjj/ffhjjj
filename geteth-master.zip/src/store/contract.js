import abi from "../assets/abi";

const contractAddress = "0xccf27eb1e27c32ba53a82a0dd46bb80f51c74252";
let contract = null;
if (window.web3) {
  contract = window.web3.eth.contract(abi).at(contractAddress);
  window.contract = contract;
}

export default (state = contract, action) => state;
