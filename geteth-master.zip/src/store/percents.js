const percents = {
  buy: 10,
  sell: 5,
  transfer: 1
};

export default (state = percents, action) => state;
