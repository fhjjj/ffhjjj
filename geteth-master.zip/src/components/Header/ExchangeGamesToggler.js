import React from 'react';
import text from '../../assets/text/header.json';

const ExchangeGamesToggler = ({isOnExchange, lang}) => {
  return (
    <a
      href={'https://geteth.io/casino'}
      className="exchange-games-toggler"
    >
      <div className={isOnExchange ? 'nav active' : 'nav'}>
        {text[lang].exchange}
      </div>
      <div className="circle-container">
        <div className={`circle ${!isOnExchange && 'exchange'}`} />
      </div>
      <div className={!isOnExchange ? 'nav active' : 'nav'}>
        {text[lang].casino}
      </div>
    </a>
  );
};

export default ExchangeGamesToggler;
