import React from "react";
import { connect } from "react-redux";
import logo from "../../assets/icons/logos/logo1.png";
import "./style.sass";
import Language from "./Language";
import ExchangeGamesToggler from "./ExchangeGamesToggler";
// import text from "../../assets/text/header.json";
import telegram from "../../assets/icons/socials/telegram.png";
// import twitter from "../../assets/icons/socials/twitter.png";
import email from "../../assets/icons/socials/email.png";
import discord from "../../assets/icons/socials/discord.png";
import links from "../../assets/text/footer.json";
// import metamask from "../../assets/metamask1.png";
// import trust from "../../assets/trust1.png";

const IconLinks = ({ fixed, lang }) => {
  const { tchan, tchat, dis } = links[lang];
  return (
    <div
      className={
        fixed
          ? "d-xl-flex align-items-center d-none socials-container fixed"
          : "d-flex d-xl-none socials-container"
      }
    >
      <a className="icon" target="_blank" href={tchat}rel="noopener noreferrer">
        <div
          className="social-wrap short"
          style={{
            backgroundImage: `url(${telegram})`
          }}
        />
      </a>
      <a className="icon" target="_blank" href={tchan}rel="noopener noreferrer">
        <div
          className="social-wrap short"
          style={{
            backgroundImage: `url(${telegram})`
          }}
        />
      </a>
      <a className="icon" target="_blank" href={dis}rel="noopener noreferrer">
        <div
          className="social-wrap"
          style={{
            backgroundImage: `url(${discord})`
          }}
        />
      </a>
      <a className="icon" target="_blank" href="mailto:admin@geteth.io">
        <div
          className="social-wrap short"
          style={{
            backgroundImage: `url(${email})`
          }}
        />
      </a>
    </div>
  );
};

const Menu = ({ lang }) => (
  <div className="menu">
    <a href="https://geteth.io/guarantees">Guarantees</a>
    <a href="https://geteth.io/risks">Risks</a>
    <a href="#faq">FAQ</a>
  </div>
);

class Header extends React.Component {
  state = {
    isOpened: false
  };
  render() {
    return (
      <div className={`${this.state.isOpened && "is-opened"} header-container`}>
        <div className="container">
          <div className="row">
            <div className="col-xl-2 col-8 d-flex justify-content-start align-items-center">
              <a
                href="/"
                style={{ zIndex: 100 }}
              >
                <div className="logo">
                  <img src={logo} alt="geteth" />
                </div>
              </a>
            </div>
            {!this.props.isOnMain ? (
              <div className="col-xl-10 col-4 d-xl-flex d-none justify-content-end align-items-center">
                <div className="d-flex">
                  <Menu lang={this.props.lang} />
                  <ExchangeGamesToggler
                    lang={this.props.lang}
                    isOnExchange={this.props.isOnExchange}
                  />
                  <Language />
                </div>
              </div>
            ) : (
              <div className="col-xl-10 col-4 d-xl-flex d-none justify-content-end align-items-center">
                <Menu lang={this.props.lang} />
                <ExchangeGamesToggler
                  lang={this.props.lang}
                  isOnExchange={this.props.isOnExchange}
                />
                <Language />
              </div>
            )}
            <div className="col-4 d-xl-none d-flex justify-content-end">
              <div
                className="icon"
                onClick={() =>
                  this.setState({ isOpened: !this.state.isOpened })
                }
              >
                <i className="fa fa-bars" />
              </div>
            </div>
          </div>
        </div>
        <div className="mobile">
          <Menu
            lang={this.props.lang}
            isOnMain={this.props.isOnMain}
            closeMenu={() => this.setState({ isOpened: false })}
          />
          <ExchangeGamesToggler
            lang={this.props.lang}
            isOnExchange={this.props.isOnExchange}
          />

          <IconLinks
            lang={this.props.lang}
            closeMenu={() => this.setState({ isOpened: false })}
          />
          <Language />
        </div>
        <IconLinks lang={this.props.lang} fixed={true} />
      </div>
    );
  }
}

export default connect(state => ({
  lang: state.lang
}))(Header);
