import React from 'react';
import smallLogo from '../../assets/icons/logos/mini-logo.png';
import exchangeSmallLogo from '../../assets/icons/logos/exchange-mini-logo.png';
import {connect} from 'react-redux';
import './style.sass';
import headers from '../../assets/text/footer.json';
import games from '../../assets/text/games.json';

class Footer extends React.Component {
  state = {
    network: 'not connected',
    balance: 0
  };
  componentDidMount() {
    // let {network, balance} = this.state;
    // if(window.web3){
    // 	window.web3.version.getNetwork((err, type) => {
    // 		switch(type){
    // 			case 1:
    // 				network = 'main net';
    // 				break;
    // 			default:
    // 				network: 'testnet'
    // 				break;
    // 		}
    // 	})
    // 	window.web3.eth.getAccounts((err, accounts) => {
    // 		if(accounts.length){
    // 			const accountAddress = accounts[0];
    // 			fetch('')
    // 		}
    // 	})
    // }
  }
  render() {
    // console.log(games);
    const {
      arr,
      games: gamesString,
      reach,
      featured,
      block4,
      terms,
      tchat,
      tchan,
      dis
    } = headers[this.props.lang];
    const {
      coin: {name: coin},
      dice: {name: dice},
      twoDice: {name: twoDice},
      etheroll: {name: etheroll}
    } = games[this.props.lang];
    return (
      <footer>
        <div className="container">
          <div className="row">
            <div className="offset-lg-1 col-lg-8">
              <div className="row d-flex justify-content-center">
                <div className="col-md-3  col-6 d-flex flex-column">
                  <div className="title">{gamesString}</div>
                  <a href="/getcoin">{coin}</a>
                  <a href="/getdice">{dice}</a>
                  <a href="/get2dice">{twoDice}</a>
                  <a href="/getroll">{etheroll}</a>
                </div>

                <div className="col-md-3 right col-6 d-flex flex-column">
                  <div className="title">{reach}</div>
                  <a target="_blank" href={tchat} rel="noopener noreferrer">
                    Telegram CHAT
                  </a>
                  <a target="_blank" href={tchan} rel="noopener noreferrer">
                    Telegram CHANNEL
                  </a>
                  <a target="_blank" href={dis} rel="noopener noreferrer">
                    Discord
                  </a>
                  <a target="_blank" href="https://github.com/GetETH" rel="noopener noreferrer">
                    Github
                  </a>
                </div>
                <div className="col-md-3   col-6 d-flex flex-column">
                  <div className="title">{featured}</div>
                  <a
                    target="_blank"
                    href="https://etherscan.io/address/0x7409a88f44ac96cfae981f444d377b025002906a"
                    rel="noopener noreferrer"
                  >
                    Smart-contract
                  </a>
                  <a
                    target="_blank"
                    href="https://incrypto.io/audit/GETETH.pdf"
                    rel="noopener noreferrer"
                  >
                    Security Audit
                  </a>
                  <a target="_blank" href="https://dappradar.com/" rel="noopener noreferrer">
                    DappRadar
                  </a>
                  <a target="_blank" href="https://medium.com" rel="noopener noreferrer">
                    Medium
                  </a>
                </div>
                <div className="col-md-3  right col-6 d-flex  flex-column">
                  <div className="title">{block4}</div>
                  <a href="/">Exchange</a>
                  <a href="/disclaimer" target="_blank">
                    Disclaimer
                  </a>
                  <a href="/lottery">Lottery</a>
                  <a href="/">FAQ</a>
                </div>
              </div>
            </div>
            <div className="col-3 d-lg-flex d-none align-items-center justify-content-center flex-column">
              <div className="logo">
                <img
                  src={this.props.isOnExchange ? exchangeSmallLogo : smallLogo}
                  alt=""
                />
              </div>
              <p>
                ©2019 GETETH <br /> {arr}.
                <br />{' '}
                <a
                  target="_blank"
                  href="/disclaimer"
                  style={{fontSize: 10, color: '#777'}}
                >
                  {terms}
                </a>
              </p>
            </div>
          </div>
        </div>
      </footer>
    );
  }
}

export default connect(state => ({
  lang: state.lang
}))(Footer);
