import React from 'react';
import metamask from '../../assets/meta-popup.png';
import trust from '../../assets/trust1.png';
import './style.sass';

export default ({status}) => {
  let content;
  switch (status) {
    case 'LOADING':
    case 'OK':
      return null;
    case 'NOT_INSTALLED':
      content = (
        <div className="d-flex justify-content-center" style={{width: '100%'}}>
          <div className="col-lg-7 col-md-10 col-sm-11 d-none d-sm-block">
            <div className="img-wrap">
              <img src={metamask} alt="" />
            </div>
            <p>
              To access the site use a browser with a MetaMask extension
              installed
            </p>
            <div className="extensions">
              <div className="text">Metamask extension for</div>
              <a href="https://onliner.by" className="extension">
                <i className="fab fa-chrome" />
              </a>
              <a href="https://onliner.by" className="extension">
                <i className="fab fa-opera" />
              </a>
              <a href="https://onliner.by" className="extension">
                <i className="fab fa-firefox" />
              </a>
            </div>
          </div>
          <div className="d-flex d-sm-none flex-column align-items-center">
            <div className="img-wrap" style={{width: '50%', maxWidth: 170}}>
              <img src={trust} alt="" />
            </div>
            <p>In order to use this app, use trust wallet, please</p>

            <div className="extensions">
              <div className="text">Trust for</div>
              <a href="https://onliner.by" className="extension">
                <i className="fab fa-android" />
              </a>
              <a href="https://onliner.by" className="extension">
                <i className="fab fa-apple" />
              </a>
            </div>
          </div>
        </div>
      );
      break;
    case 'NOT_LOGGED_IN':
      content = (
        <div className="d-flex justify-content-center" style={{width: '100%'}}>
          <div className="col-lg-7 col-md-10 col-sm-11 d-none d-sm-block">
            <div className="img-wrap">
              <img src={metamask} alt="" />
            </div>
            <p>Login to use this site, please</p>
          </div>
          <div className="d-flex d-sm-none flex-column align-items-center">
            <a
              href="https://onliner.by"
              className="img-wrap"
              style={{width: '50%', maxWidth: 170}}
            >
              <img src={trust} alt="" />
            </a>
            <p>Login to use this site, please</p>
          </div>
        </div>
      );
      break;
    case 'WRONG_NETWORK':
      content = (
        <div className="d-flex justify-content-center" style={{width: '100%'}}>
          <div className="col-lg-7 col-md-10 col-sm-11 d-none d-sm-block">
            <div className="img-wrap">
              <img src={metamask} alt="" />
            </div>
            <p>Switch network to Mainnet, please</p>
          </div>
          <div className="d-flex d-sm-none flex-column align-items-center">
            <div className="img-wrap" style={{width: '50%', maxWidth: 170}}>
              <img src={trust} alt="" />
            </div>
            <p>Switch network to Mainnet, please</p>
          </div>
        </div>
      );
      break;
    default:
      content = <div />;
      break;
  }
  return (
    <div className="metamask-error">
      <div className="container">
        <div className="row d-flex justify-content-center align-items-center">
          {content}
        </div>
      </div>
    </div>
  );
};
