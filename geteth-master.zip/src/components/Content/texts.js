import text from '../../assets/text/comparision.json';
import {shortAddr} from "../../utils";

export const comparisions = lang => [
    {
        advantage: text[lang].advantages.buy,
        geteth: {
            value: '10%',
            advantage: true,
        },
        ect: {
            value: '12%',
            advantage: false,
        },
        pantheon: {
            value: '10%',
            advantage: true,
        },
        cmt: {
            value: '10%',
            advantage: true,
        },
        powh: {
            value: '10%',
            advantage: true,
        },
    },
    {
        advantage: text[lang].advantages.sell,
        geteth: {
            value: '5%',
            advantage: true,
        },
        ect: {
            value: '6-30%',
            advantage: false,
        },
        pantheon: {
            value: '5%',
            advantage: true,
        },
        cmt: {
            value: '5%',
            advantage: true,
        },
        powh: {
            value: '10%',
            advantage: false,
        },
    },
    {
        advantage: text[lang].advantages.admin,
        geteth: {
            value: text[lang].no,
            advantage: true,
        },
        ect: {
            value: text[lang].yes,
            advantage: false,
        },
        pantheon: {
            value: text[lang].no,
            advantage: true,
        },
        cmt: {
            value: text[lang].no,
            advantage: true,
        },
        powh: {
            value: text[lang].no,
            advantage: true,
        },
    },
    {
        advantage: text[lang].advantages.audit,
        geteth: {
            value: text[lang].yes,
            advantage: true,
        },
        ect: {
            value: text[lang].no,
            advantage: false,
        },
        pantheon: {
            value: text[lang].yes,
            advantage: true,
        },
        cmt: {
            value: text[lang].yes,
            advantage: true,
        },
        powh: {
            value: text[lang].yes,
            advantage: true,
        },
    },
    {
        advantage: text[lang].advantages.instruction,
        geteth: {
            value: text[lang].yes,
            advantage: true,
        },
        ect: {
            value: text[lang].no,
            advantage: false,
        },
        pantheon: {
            value: text[lang].no,
            advantage: false,
        },
        cmt: {
            value: text[lang].no,
            advantage: false,
        },
        powh: {
            value: text[lang].yes,
            advantage: true,
        },
    },
    {
        advantage: text[lang].advantages.refProgramm,
        geteth: {
            value: '5%',
            advantage: true,
        },
        ect: {
            value: '2%',
            advantage: false,
        },
        pantheon: {
            value: '3.3%',
            advantage: false,
        },
        cmt: {
            value: '3.3%',
            advantage: false,
        },
        powh: {
            value: '3.3%',
            advantage: false,
        },
    },
    {
        advantage: text[lang].advantages.otherProductsIncome,
        geteth: {
            value: text[lang].yes,
            advantage: true,
        },
        ect: {
            value: text[lang].yes,
            advantage: true,
        },
        pantheon: {
            value: text[lang].no,
            advantage: false,
        },
        cmt: {
            value: text[lang].no,
            advantage: false,
        },
        powh: {
            value: text[lang].yes,
            advantage: true,
        },
    },
    {
        advantage: text[lang].advantages.minDeoposit,
        geteth: {
            value: text[lang].no,
            advantage: true,
        },
        ect: {
            value: text[lang].yes,
            advantage: false,
        },
        pantheon: {
            value: text[lang].yes,
            advantage: false,
        },
        cmt: {
            value: text[lang].yes,
            advantage: false,
        },
        powh: {
            value: text[lang].yes,
            advantage: false,
        },
    },
];

export const textPage = {
    eng: {
        textPreview: 'this is an investment cryptocurrency exchange based on the Ethereum smart contract.',
        balance: 'Token balance',
        priceTitle: 'Tokens price',
        save: 'Savings',
        revenue: ['Revenue from CASINO', 'Revenue from INVEST', 'Revenue from Referral program'],
        result: ['Widthdrawal', 'ReInvest', 'Transfer Tokens'],
        stat: ['Statistics of your income', 'Day', 'Week', 'Month', 'All the time'],
        tar: ['Cost vs ETH/contact', 'Forecasting of amount'],
        count: ['Token vs ETH/contract', 'Forecasting of prices'],
        buying: ['Buying tokens', 'To enrollment', 'Purchase fee', 'Buy Tokens'],
        selling: ['Selling tokens', 'Sell Tokens', 'Purchase fee', 'Sell Tokens'],
        ref: ['Your referral link', 'Rewards of the referral program', 'Data on awards are not yet available'],
        price: ['PRICE', 'TOTAL SUPPLY', 'BALANCE', 'TRANSACTIONS'],
        adv: 'ADVANTAGES',
        walletsWarning: 'Do not send your ETH from exchange-traded wallets to the GetETH smart contract or your GET tokens will be lost!',
        investedNotify: (txHash, buyer, amount) => `${buyer} <a href="https://etherscan.io/tx/${txHash}" target="_blank">invested ${amount} ETH</a>`,
    },
    rus: {
        textPreview: 'это инвестиционная криптовалютная биржа, основанная на смарт-контракте Ethereum.',
        balance: 'Баланс токенов',
        priceTitle: 'Цена токена',
        save: 'Накопления',
        revenue: ['Казино', 'От инвестиций', 'От реферальной программы'],
        result: ['Вывод', 'Реинвест', 'Перевод токенов'],
        stat: ['Статистика доходности', 'День', 'Неделя', 'Месяц', 'За все время'],
        tar: ['ЦЕНА vs ETH/contract', 'Прогноз роста цены'],
        count: ['ТОКЕН vs ETH/contract', 'Прогноз количества'],
        buying: ['Покупка токенов', 'Вы получите', 'Комиссия', 'Купить'],
        selling: ['Продажа токенов', 'Продать', 'Комиссия', 'Продать'],
        ref: [
            'Ваша реферальная ссылка',
            'Начисления по реферальной программе',
            'Данные о начислениях пока отсутствуют',
        ],
        price: ['ЦЕНА', 'ВСЕГО ВЫПУЩЕНО/ВСЕГО В ОБРАЩЕНИИ', 'БАЛАНС СК/ВСЕГО НА СК', 'ВСЕГО ИСХОДЯЩИХ ТРАНЗАКЦИЙ'],
        adv: 'ПРЕИМУЩЕСТВА',
        walletsWarning: 'Не отправляйте ваши ETH с биржевых кошельков на адрес смарт-контракта GetETH, иначе Ваши токены GET будут потеряны!',
        investedNotify: (txHash, buyer, amount) => `${buyer} <a href="https://etherscan.io/tx/${txHash}" target="_blank">инвестировал ${amount} ETH</a>`,
    },
};
