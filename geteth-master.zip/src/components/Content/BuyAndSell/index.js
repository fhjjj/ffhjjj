import React from 'react';
import Card from './Card';
import { connect } from 'react-redux';
import { textPage } from '../texts';

class BuyAndSell extends React.Component {
    buy = eth => {
        const ref = new URL(window.location.href).searchParams.get('ref');
        console.log(ref);
        if (eth)
            this.props.contract.buyTokens.sendTransaction(
                window.web3.isAddress(ref) ? ref : '0x0',
                {
                    from: window.web3.eth.defaultAccount,
                    value: window.web3.toWei(eth),
                },
                (err, txhash) => {
                    console.log('buy success', txhash);
                },
            );
    };
    sell = get => {
        if (get)
            this.props.contract.sellTokens.sendTransaction(
                get,
                {
                    from: window.web3.eth.defaultAccount,
                },
                (err, txhash) => console.log('buy success', txhash),
            );
    };
    render() {
        // const { courses } = this.props;
        const { lang } = this.props;

        return (
            <div className="buy-and-sell-container">
                <div className="row">
                    <Card
                        type="buy"
                        buttonText={textPage[lang].buying[3]}
                        enrollmentCurrency="GET"
                        currency="ETH"
                        headerText={textPage[lang].buying[0]}
                        fee={this.props.percents.buy}
                        max={this.props.balance.eth}
                        calculatePayout={eth =>
                            (Math.sqrt(
                                (120 + (this.props.totalSupply - 1) * 10) *
                                    1000000000 *
                                    ((120 + (this.props.totalSupply - 1) * 10) * 1000000000) +
                                    20 * eth * 1000000000 * 1000000000000000000,
                            ) -
                                (120 + (this.props.totalSupply - 1) * 10) * 1000000000) /
                            10000000000
                        }
                        action={this.buy}
                        dollarCourse={this.props.courses.ethDollar}
                        enrollmentSigns={0}
                    />
                    <Card
                        type="sell"
                        buttonText={textPage[lang].selling[1]}
                        headerText={textPage[lang].selling[0]}
                        enrollmentCurrency="ETH"
                        currency="GET"
                        calculatePayout={get =>
                            (((120 + (this.props.totalSupply - 1) * 10) * 1000000000 * get -
                                get * get * 5 * 1000000000) /
                                1000000000000000000) *
                            0.95
                        }
                        fee={this.props.percents.sell}
                        max={this.props.balance.get}
                        course={this.props.courses.getEth}
                        action={this.sell}
                        dollarCourse={this.props.courses.getEth * this.props.courses.ethDollar}
                        enrollmentSigns={3}
                    />
                    <div className='wallets-warning'>{textPage[lang].walletsWarning}</div>
                </div>
            </div>
        );
    }
}

export default connect(state => ({
    percents: state.percents,
    balance: state.values.balance,
    contract: state.contract,
    courses: state.courses,
    totalSupply: state.values.other.totalSupply,
    lang: state.lang,
}))(BuyAndSell);
