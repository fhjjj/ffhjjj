import React from 'react';
import Description from './Description';
import Statisctics from './Statistics';
import Graphs from './Graphs';
import BuyAndSell from './BuyAndSell/index';
import Referral from './Referral';
import Details from './Details';
import Comparision from './Comparision';
import FAQ from './FAQ';
import './style.sass';
import InvestTicker from "./InvestTicker";

export default () => (
  <div className="container">
    <Description />
    <Statisctics />
    <Graphs />
    <BuyAndSell />
    <Referral />
    <Details />
    <Comparision />
    <FAQ />
    <InvestTicker />
  </div>
);
