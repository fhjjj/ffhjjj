import React from 'react';

export default () => (
  <div className="description-container circled">
    <div className="row">
      <div className="col-md-8 col-lg-6">
        <h1>GETETH SMART INVEST</h1>
        <p>
          this is an investment cryptocurrency exchange based on the Ethereum
          smart contract.
        </p>
      </div>
    </div>
  </div>
);
