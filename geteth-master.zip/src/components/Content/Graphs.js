import React from 'react';
import { Line as LineChart } from 'react-chartjs-2';
import { connect } from 'react-redux';
import { textPage } from './texts';
import * as _ from 'lodash';
const whiteColor = '#FFF';

const commonData = {
    datasets: [
        {
            fill: false,
            lineTension: 0.5,
            borderColor: whiteColor,
            borderDashOffset: 0.0,
            pointBackgroundColor: whiteColor,
            pointBorderWidth: 1,
            pointHoverRadius: 8,
            pointHoverBorderWidth: 2,
            pointRadius: 4,
            pointHitRadius: 10,
            spanGaps: true,
        },
    ],
};

const options = {
    maintainAspectRatio: false,
    legend: {
        display: false,
    },
    tooltips: {
        callbacks: {
            label: function(tooltipItem, data) {
                return +tooltipItem.yLabel.toFixed(5);
            },
        },
    },
    scales: {
        yAxes: [
            {
                gridLines: {
                    zeroLineColor: '#fff',
                    color: '#fff',
                    beginAtZero: true,
                },
                ticks: {
                    fontColor: '#fff',
                    callback: function(value, index, values) {
                        return +value.toFixed(4);
                    },
                    maxTicksLimit: 5,
                },
            },
        ],
        xAxes: [
            {
                gridLines: {
                    display: false,
                    color: '#fff',
                },
                ticks: {
                    fontColor: '#ffffff',
                    callback: function(value, index, values) {
                        return +value.toFixed(4);
                    },
                },
            },
        ],
    },
};

const tokenOptions = _.cloneDeep(options);
tokenOptions.scales.xAxes[0].scaleLabel = {
    display: true,
    labelString: 'ETH on contract',
    fontColor: '#ccc',
};
tokenOptions.scales.yAxes[0].scaleLabel = {
    display: true,
    labelString: 'Issued tokens amount',
    fontColor: '#ccc',
};

const costOptions = _.cloneDeep(options);
costOptions.scales.xAxes[0].scaleLabel = {
    display: true,
    labelString: 'Issued tokens amount',
};
costOptions.scales.yAxes[0].scaleLabel = {
    display: true,
    labelString: 'Token price in ETH',
};

class Graphs extends React.Component {
    getTokenData() {
        const data = _.cloneDeep(commonData);
        data.labels = [];
        data.datasets[0].data = [];

        const p = this.props.price;

        for (let i = 0; i < 10; i++) {
            data.datasets[0].data.push(this.props.totalSupply + 1000 * i);
            data.labels.push(this.props.balance + (i * p + (10e-9 * i * (i + 1)) / 2));
        }
        return data;
    }

    getCostData() {
        const data = _.cloneDeep(commonData);
        data.labels = [];
        data.datasets[0].data = [];

        for (let i = 0; i < 10; i++) {
            const supply = this.props.totalSupply * (i + 1);
            data.datasets[0].data.push(105e-9 + 10e-9 * supply);
            data.labels.push(supply);
        }
        return data;
    }

    render() {
        const { lang } = this.props;
        return (
            <div className="graphs-container">
                <div className="row">
                    <div className="col-md-6">
                        <div className="graph-container green circled">
                            <div className="graph-title">{textPage[lang].tar[0]}</div>
                            <div className="graph">
                                <LineChart
                                    data={this.getCostData()}
                                    options={{
                                        ...costOptions,
                                    }}
                                />
                            </div>
                            <div className="graph-description">{textPage[lang].tar[1]}</div>
                        </div>
                    </div>
                    <div className="col-md-6">
                        <div className="graph-container blue circled">
                            <div className="graph-title">{textPage[lang].count[1]}</div>

                            <div className="graph">
                                <LineChart
                                    data={this.getTokenData()}
                                    options={{
                                        ...tokenOptions,
                                    }}
                                />
                            </div>
                            <div className="graph-description">{textPage[lang].count[1]}</div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default connect(state => ({
    price: state.courses.getEth,
    balance: state.values.other.contractBalance,
    totalSupply: state.values.other.totalSupply,
    lang: state.lang,
}))(Graphs);
